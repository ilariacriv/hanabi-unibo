/**
 * Il package api.client contiene due classi
 */
package api.client;
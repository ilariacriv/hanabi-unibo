/**
 * HanAPI &egrave; una libreria di supporto alla programmazione di un client per HanabiEngine.
 */
package api;